
public interface Comparable {
		

}
