import java.util.ArrayList;

public class Faturamento  {
    private Empresa empresa;
	private Double somaNotas;
	ArrayList<NotaFiscal> notasFiscaisSoma = new ArrayList<> ();




		
		
			
		
	
	

}