import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
	}
	
	private static void CriarListadeContato () {
		
		ArrayList <Contato> contatos = new ArrayList<> ();
		
		String[] opc = {"Inserir contato", "Listar contatos"};
		boolean continua =  true;
		int opcao = Console.mostrarMenu(opc, "lista 06", null)
		
		switch(opcao) {
		
		case 1: 
		
			break;
		
		case 2:
			
			break;
		
		}
 		
		
		
		
	}
	
	private static Contato criarContato() {
		
		
		Integer codigo = Console.recuperaInteiro("Informe o codigo");
		String nome = Console.recuperaTexto("Informe o nome do conatato");
		String telefone = Console.recuperaTexto("Informe o numero de telefone");
		String tipoContato = Console.recuperaTexto("Digite p para pessoal ou qualquer outra coisa para comercial");
		Contato contato = null;
		
		if ("p".equalsIgnoreCase(tipoContato)) {
			
	  String celular = Console.recuperaTexto("Informe o celular");
	  contato= new Pessoal(codigo,nome,telefone, celular);
	  
			
		}else if 
		{
			String 
		}
			
		
		
	}
	
	
}
