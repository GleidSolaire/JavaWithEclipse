
public class Familiar extends Contato {

	private String grauParentesco;

	public Familiar(Integer codigo, String nome, String telefone, String grauParentesco) {
		super(codigo, nome, telefone);
		this.grauParentesco = grauParentesco;
	}

	public String getGrauParentesco() {
		return grauParentesco;
	}

	public void setGrauParentesco(String grauParentesco) {
		this.grauParentesco = grauParentesco;
	}

	@Override
	public String toString() {
		return super.toString()+"\n Grau de Parentesco"+this.grauParentesco;
	}
	
	
	
	
}
